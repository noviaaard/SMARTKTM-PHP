<?php
    require 'database.php';
    $no_kartu = null;
    if ( !empty($_GET['no_kartu'])) {
        $no_kartu = $_REQUEST['no_kartu'];
    }
     
    $pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM mahasiswa where no_kartu = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($no_kartu));
	$data = $q->fetch(PDO::FETCH_ASSOC);
	Database::disconnect();
	
	$msg = null;
	if (null==$data['nama_mhs']) {
		$msg = "ID Kartu belum terdaftar !!!";
		$data['no_kartu']=$no_kartu;
		$data['id']="--------";
	} else {
		$msg = null;
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
	    <link   href="css/bootstrap.min.css" rel="stylesheet">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
		<style>
			td.lf {
				padding-left: 15px;
				padding-top: 12px;
				padding-bottom: 12px;
			}
		</style>
	</head>
 
	<body>	
		<div class="container">
			<br>
			<div class="center" style="margin: 0 auto; width:495px; border-style: solid; border-color: #f2f2f2;">
				<div class="row">
					<h3 align="center">Kendaraan Terparkir</h3>
				</div>
				<br>
					<form class="form-horizontal" action="insertmasuk.php" method="post">
						<div class="control-group">
							<label class="control-label">No. Kartu</label>
							<div class="controls">
								<input id="no_kartu" type="text" name="no_kartu" value="<?php echo $data['no_kartu'];?>" required>
							</div>
						</div>
						<div class="control-group" hidden>
							<label class="control-label">Mahasiswa ID</label>
							<div class="controls">
								<input id="mhs_id" name="id" type="text"  placeholder="" value="<?php echo $data['id'];?>" required>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">Nama</label>
							<div class="controls">
								<input id="nama" type="text" name="saldo" value="<?php echo $data['nama_mhs'];?>" required>
							</div>
						</div>
						<div class="form-actions">
								<button type="submit" class="btn btn-success">Simpan</button>
		                </div>
					</form>
			</div>
		<p style="color:red;"><?php echo $msg;?></p>
		
	</body>
</html>