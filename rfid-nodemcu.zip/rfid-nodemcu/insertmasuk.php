<?php
     
    require 'database.php';

    if ( !empty($_POST)) {
        
        // keep track post values
        ini_set('date.timezone', 'Asia/Jakarta');
        $mhs_id = $_POST['id'];
        $no_kartu = $_POST['no_kartu'];
        $jam_masuk = date("Y-m-d H:i:s");
        $status = 'masuk';

        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO parkirs (mhs_id, no_kartu, jam_masuk, status) values(?,?,?,?)";
        $q = $pdo->prepare($sql);
		$q->execute(array($mhs_id,$no_kartu,$jam_masuk,$status));
        if (mysqli_affected_rows($sql) > 0 ):
            echo '<script>
            alert("Data Berhasil")
            document.location.herf = "parkirmasuk.php"
            </script>';
        endif;
        
        Database::disconnect();
		header("Location: parkirmasuk.php");
    }

?>
