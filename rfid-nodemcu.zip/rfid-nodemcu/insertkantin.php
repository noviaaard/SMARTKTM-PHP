<?php
     
    require 'database.php';

    if ( !empty($_POST)) {
        
        // keep track post values
        ini_set('date.timezone', 'Asia/Jakarta');
        $mhs_id = $_POST['id'];
        $penjual_id = $_POST['penjual_id'];
        $no_kartu = $_POST['no_kartu'];
        $jam_transaksi = date("Y-m-d H:i:s");
        $saldo = $_POST['saldo'];
        $saldo_penjual = $_POST['saldo_penjual'];
        $id = $_POST['id'];

        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if($saldo < 10000) {
            echo "<script language='JavaScript'>
                     alert('Saldo anda tidak cukup');
                     document.location='kantin.php';
                 </script>";
         } else {

		$sql = "INSERT INTO kantins (mhs_id, penjual_id, no_kartu, jam_transaksi) values(?,?,?,?)";
        $q = $pdo->prepare($sql);
		$q->execute(array($mhs_id,$penjual_id,$no_kartu,$jam_transaksi));

            
        $sql = "UPDATE mahasiswa SET saldo = $saldo - 10000 where no_kartu = '$no_kartu' ";
        $q = $pdo->prepare($sql);
        $q->execute(array($saldo));


        $sql = "UPDATE penjual SET saldo_penjual = saldo_penjual + 10000 where id = '$penjual_id' ";
        $q = $pdo->prepare($sql);
        $q->execute(array($saldo_penjual));
        
        Database::disconnect();
		header("Location: kantin.php");
        
        }
    }

?>

