<?php
    require 'database.php';
    $no_kartu = null;
    if ( !empty($_GET['no_kartu'])) {
        $no_kartu = $_REQUEST['no_kartu'];
    }
    $pdo = Database::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM mahasiswa where no_kartu = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($no_kartu));
	$data = $q->fetch(PDO::FETCH_ASSOC);
	Database::disconnect();
	$msg = null;
	if (null==$data['nama_mhs']) {
		$msg = "Kartu Belum Terdaftar !!!";
		$data['no_kartu']=$no_kartu;
		$data['nama_mhs']="--------";
		$data['saldo']="--------";
	} else {
		$msg = null;
	}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
	<style>
		td.lf {
			padding-left: 15px;
			padding-top: 12px;
			padding-bottom: 12px;
		}
	</style>
</head>
 
	<body>	
		<div>
			<form>
				<table  width="452" border="1" bordercolor="#10a0c5" align="center"  cellpadding="0" cellspacing="1"  bgcolor="#000" style="padding: 2px">
					<tr>
						<td  height="40" align="center"  bgcolor="#10a0c5"><font  color="#FFFFFF">
						<b>User Data</b></font></td>
					</tr>
					<tr>
						<td bgcolor="#f9f9f9">
							<table width="452"  border="0" align="center" cellpadding="5"  cellspacing="0">
								<tr>
									<td width="113" align="left" class="lf">No. Kartu</td>
									<td style="font-weight:bold">:</td>
									<td align="left"><?php echo $data['no_kartu'];?></td>
								</tr>
								<tr bgcolor="#f2f2f2">
									<td align="left" class="lf">Nama </td>
									<td style="font-weight:bold">:</td>
									<td align="left"><?php echo $data['nama_mhs'];?></td>
								</tr>
								<tr bgcolor="#f2f2f2">
									<td align="left" class="lf">NIM </td>
									<td style="font-weight:bold">:</td>
									<td align="left"><?php echo $data['nim'];?></td>
								</tr>
								<tr bgcolor="#f2f2f2">
									<td align="left" class="lf">Saldo </td>
									<td style="font-weight:bold">:</td>
									<td align="left"><?php echo $data['saldo'];?></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</form>
		</div>
		<p style="color:red;"><?php echo $msg;?></p>
	</body>
</html>