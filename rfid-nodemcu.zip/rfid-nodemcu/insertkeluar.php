<?php
     
    require 'database.php';

    if ( !empty($_POST)) {
        
        // keep track post values
        ini_set('date.timezone', 'Asia/Jakarta');
        $mhs_id = $_POST['mhs_id'];
        $no_kartu = $_POST['no_kartu'];
        $jam_masuk = $_POST['jam_masuk'];
        $jam_keluar = date("Y-m-d H:i:s");
        $saldo = $_POST['saldo'];
        $id = $_POST['id'];

        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if($saldo < 3000) {
            echo "<script language='JavaScript'>
                     alert('Saldo anda tidak cukup');
                     document.location='parkirkeluar.php';
                 </script>";
         } else {

		$sql = "INSERT INTO dataparkirs (mhs_id, no_kartu, jam_masuk, jam_keluar) values(?,?,?,?)";
        $q = $pdo->prepare($sql);
		$q->execute(array($mhs_id,$no_kartu,$jam_masuk,$jam_keluar));
  
        $sql = "UPDATE mahasiswa SET saldo = $saldo - 3000 where no_kartu = '$no_kartu' ";
        $q = $pdo->prepare($sql);
        $q->execute(array($saldo));

        $sql = "DELETE FROM parkirs WHERE no_kartu = '$no_kartu'";
        $step=$pdo->prepare($sql);
        $step->execute();
        
        Database::disconnect();
		header("Location: parkirkeluar.php");
        
        }
    }

?>

