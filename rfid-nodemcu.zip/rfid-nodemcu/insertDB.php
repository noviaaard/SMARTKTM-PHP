<?php
     
    require 'database.php';
 
    if ( !empty($_POST)) {
        // keep track post values
        $nama_mhs = $_POST['nama_mhs'];
		$no_kartu = $_POST['no_kartu'];
		$nim = $_POST['nim'];
        $email = $_POST['email'];
        $no_telfon = $_POST['no_telfon'];
        $tempat_lahir = $_POST['tempat_lahir'];
        $tgl_lahir = $_POST['tgl_lahir'];
        $kelas = $_POST['kelas'];
        $jurusan = $_POST['jurusan'];
        $alamat = $_POST['alamat'];
        $saldo = $_POST['saldo'];
        $topup = $_POST['topup'];
        
		// insert data
        $pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "INSERT INTO mahasiswa (nama_mhs,no_kartu,nim,email,no_telfon, tempat_lahir, tgl_lahir, kelas, jurusan, alamat,saldo,topup) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";
		$q = $pdo->prepare($sql);
		$q->execute(array($nama_mhs,$no_kartu,$nim,$email,$no_telfon,$tempat_lahir,$tgl_lahir,$kelas,$jurusan,$alamat,$saldo,$topup));
		Database::disconnect();
		header("Location: http://localhost:8000/manjmhs");
    }

?>