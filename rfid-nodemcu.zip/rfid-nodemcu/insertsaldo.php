<?php
     
    require 'database.php';


    if ( !empty($_POST)) {
        
        // keep track post values
        ini_set('date.timezone', 'Asia/Jakarta');
        $mhs_id = $_POST['id'];
        $no_kartu = $_POST['no_kartu'];
        $nama_mhs = $_POST['nama_mhs'];
        $saldo = $_POST['saldo'];
        $topup = $_POST['topup'];
        $id = $_POST['id'];

        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		

        $sql = "UPDATE mahasiswa SET saldo = $saldo + $topup where id = $id ";
        $q = $pdo->prepare($sql);
        $q->execute(array($saldo));
        Database::disconnect();
		header("Location: topup.php");
        
    
    }
?>
